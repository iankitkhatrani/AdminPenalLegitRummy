import { createContext } from "react";

const offerContext = createContext({})

export default offerContext